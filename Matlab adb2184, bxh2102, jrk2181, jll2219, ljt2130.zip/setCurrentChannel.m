% UNIS:adb2184, bxh2102, jrk2181, jll2219, ljt2130
% This method sets the current channel for the tv.
function setCurrentChannel(val)
global tv;
tv.currentChannel = val;
end