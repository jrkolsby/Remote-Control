% UNIS:adb2184, bxh2102, jrk2181, jll2219, ljt2130
% This method sets the current volume for the tv.
function setCurrentVolume(val)
global tv;
tv.currentVolume = val;
end