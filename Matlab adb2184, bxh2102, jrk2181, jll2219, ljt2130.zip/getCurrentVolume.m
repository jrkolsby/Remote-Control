% UNIS:adb2184, bxh2102, jrk2181, jll2219, ljt2130
% This method gets the current volume for the tv.
function r = getCurrentVolume()
global tv;
r = tv.currentVolume;
end