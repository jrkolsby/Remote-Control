% UNIS:adb2184, bxh2102, jrk2181, jll2219, ljt2130
% This method gets the last channel for the tv.
function r = getLastChannel()
global tv;
r = tv.lastChannel;
end